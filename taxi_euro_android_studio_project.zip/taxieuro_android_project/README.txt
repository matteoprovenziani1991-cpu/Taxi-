taxi€ — progetto Android

Questo è un progetto sorgente per Android Studio che incorpora la versione web locale di taxi€ in una WebView Android. Include registrazione corse e spese, dashboard, report settimanali/mensili e salvataggio locale. Nel menu pagamento delle corse è stata rimossa la voce Bonifico ed è stata aggiunta Uber.

COME GENERARE L'APK
1. Scarica ed estrai lo ZIP su un computer.
2. Installa Android Studio (versione recente) e Android SDK Platform 35.
3. Apri Android Studio e scegli Open, quindi seleziona la cartella taxiEuro.
4. Attendi la sincronizzazione Gradle. Se richiesto, installa i componenti SDK suggeriti.
5. Dal menu Build scegli Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK di debug sarà normalmente in app/build/outputs/apk/debug/app-debug.apk.

NOTA IMPORTANTE
Questo ambiente non dispone degli strumenti Android/Gradle necessari per compilare e verificare direttamente un APK firmato. Il file fornito è il progetto Android pronto da aprire e compilare in Android Studio, non un APK già compilato. I dati dell'app vengono conservati nello storage locale della WebView; prima di reinstallare o cancellare i dati dell'app, esporta un backup quando possibile.
